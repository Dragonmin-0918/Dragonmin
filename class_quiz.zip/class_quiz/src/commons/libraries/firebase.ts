import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyCXYDk_xaH3cPnv8I7aKOsWjt8gbMLYRDo",
  authDomain: "test-project-eefd7.firebaseapp.com",
  projectId: "test-project-eefd7",
  storageBucket: "test-project-eefd7.appspot.com",
  messagingSenderId: "844954662018",
  appId: "1:844954662018:web:641d366d22aeeebaddf09b"
};


export const firebaseApp = initializeApp(firebaseConfig);