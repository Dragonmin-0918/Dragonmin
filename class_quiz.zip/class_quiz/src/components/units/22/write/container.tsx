import BordWriteUI from "./presenter";

export default function BordWrite (props: any): JSX.Element {


    return <BordWriteUI />
}