import { useRecoilState } from "recoil"
import { isEditState } from "../../../../../src/commons/stores/index"

export default function BordWriteUI (): JSX.Element {
    const [isEdit, setIsEdit] = useRecoilState(isEditState)

    return <h1>{isEdit ? "등록하기" : "수정하기"}</h1>
}