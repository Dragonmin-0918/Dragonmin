import styled from "@emotion/styled";

export const BlueInput = styled.input`
  border-color: blue;
`;

export const GrayButton = styled.button`
  background-color: ${(props) => (props.isActive ? "yellow" : "")};
`;
