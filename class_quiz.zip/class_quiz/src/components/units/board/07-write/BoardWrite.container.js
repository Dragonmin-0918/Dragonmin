import { useMutation } from "@apollo/client";
import { useRouter } from "next/router";
import { useState } from "react";
import { CREATE_PRODUCT } from "./BoardWrite.queries";
import BoardWriteUI from "./BoardWrite.presenter";

export default function BoardWrite(props) {
  const [isActive, setIsActive] = useState(false);
  const router = useRouter();

  const [seller, setSeller] = useState();
  const [name, setName] = useState();
  const [detail, setDetail] = useState();
  const [price, setPrice] = useState();

  const [MyFunc] = useMutation(CREATE_PRODUCT);

  const onClickSubmit = async () => {
    try {
      const result = await MyFunc({
        variables: {
          number: number,
          seller: seller,
          createProductInput: {
            name: name,
            detail: detail,
            price: Number(price),
          },
        },
      });

      router.push(`/07-moved/${result.data.createProduct._id}`);
    } catch (error) {
      alert(error.message);
    }
  };

  const onChangeSeller = (event) => {
    setSeller(event.target.value);

    if (event.target.value && name && detail && price) {
      setIsActive(true);
    }
  };

  const onChangeName = (event) => {
    setName(event.target.value);

    if (seller && event.target.value && detail && price) {
      setIsActive(true);
    }
  };

  const onChangeDetail = (event) => {
    setDetail(event.target.value);

    if (seller && name && event.target.value && price) {
      setIsActive(true);
    }
  };

  const onChangePrice = (event) => {
    setPrice(event.target.value);

    if (seller && name && detail && event.target.value) {
      setIsActive(true);
    }
  };

  return (
    <div>
      <BoardWriteUI
        onChangeSeller={onChangeSeller}
        onChangeName={onChangeName}
        onChangeDetail={onChangeDetail}
        onChangePrice={onChangePrice}
        onClickSubmit={onClickSubmit}
        isActive={isActive}
      />
    </div>
  );
}
