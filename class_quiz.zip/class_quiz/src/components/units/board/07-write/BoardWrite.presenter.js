import { BlueInput, GrayButton } from "./BoardWrite.styles";

export default function BoardWriteUI(props) {
  return (
    <div>
      판매자: <BlueInput type="text" onChange={props.onChangeSeller} />
      상품명: <BlueInput type="text" onChange={props.onChangeName} />
      상세설명: <BlueInput type="text" onChange={props.onChangeDetail} />
      가격: <BlueInput type="text" onChange={props.onChangePrice} />
      <GrayButton onClick={props.onClickSubmit} isActive={props.isActive}>
        상품등록
      </GrayButton>
    </div>
  );
}
