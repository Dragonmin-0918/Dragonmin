import { useMutation } from "@apollo/client";
import { useState } from "react";
import { CREATE_PRODUCT, UPDATE_PRODUCT } from "./ProductWrite.queries"; //export는 골라서 가져오기 가능
import ProductWriteUI from "./ProductWrite.presenter"; //export default로 한개만 가져오기
import { useRouter } from "next/router";

export default function ProductWrite(props) {
  const router = useRouter();

  const [seller, setSeller] = useState("");
  const [name, setName] = useState("");
  const [detail, setDetail] = useState("");
  const [price, setPrice] = useState("");

  const [MyFunction] = useMutation(CREATE_PRODUCT);
  const [updateProduct] = useMutation(UPDATE_PRODUCT);

  const onClickSubmit = async () => {
    try {
      const result = await MyFunction({
        variables: {
          seller: seller,
          createProductInput: {
            name: name,
            detail: detail,
            price: Number(price),
          },
        },
      });
      router.push(`/09/${result.data.createProduct._id}`);
      console.log(result);
    } catch (error) {
      alert(error.message);
    }
  };

  const onClickUpdate = async () => {
    try {
      const result = await updateProduct({
        variables: {
          productId: router.query.ID,
          updateProductInput: {
            name: name,
            detail: detail,
            price: Number(price),
          },
        },
      });
      router.push(`/09/${result.data.updateProduct._id}`);
    } catch (error) {
      alert(error.message);
    }
  };

  const onChangeSeller = (event) => {
    setSeller(event.target.value);
    console.log(seller);
  };

  const onChangeName = (event) => {
    setName(event.target.value);
    console.log(name);
  };

  const onChangeDetail = (event) => {
    setDetail(event.target.value);
    console.log(detail);
  };

  const onChangePrice = (event) => {
    setPrice(event.target.value);
    console.log(price);
  };

  return (
    <div>
      <ProductWriteUI
        onClickSubmit={onClickSubmit}
        onClickUpdate={onClickUpdate}
        onChangeSeller={onChangeSeller}
        onChangeName={onChangeName}
        onChangeDetail={onChangeDetail}
        onChangePrice={onChangePrice}
        isEdit={props.isEdit}
      />
    </div>
  );
}
