import { RedInput, BlueButton } from "./ProductWrite.styles";

export default function ProductWriteUI(props) {
  return (
    <div>
      판매자: <RedInput type="text" onChange={props.onChangeSeller} />
      상품명: <input type="text" onChange={props.onChangeName} />
      상품상세: <input type="text" onChange={props.onChangeDetail} />
      가격:
      <input type="text" onChange={props.onChangePrice} />
      <BlueButton
        button
        onClick={props.isEdit ? props.onClickUpdate : props.onClickSubmit}
      >
        {props.isEdit ? "수정" : "등록"}
      </BlueButton>
    </div>
  );
}
