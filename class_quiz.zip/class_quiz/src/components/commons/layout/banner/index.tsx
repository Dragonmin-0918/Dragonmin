import styled from "@emotion/styled";
import Slider from "react-slick";
// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";

const Wrapper = styled.div`
  height: 50px;
  background-color: lightpink;
  div {
    object-fit: cover;
  }
`;

export default function LayoutBanner(props) {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  return (
    <Wrapper>
      <Slider {...settings}>
        <div>
          <img src="/images/Developer_profile.jpeg"></img>
        </div>
        <div>
          <img src="/images/coding_01.jpeg"></img>
        </div>
        <div>
          <img src="/images/coding_00.jpeg"></img>
        </div>
      </Slider>
    </Wrapper>
  );
}
