import { useRouter } from "next/router";
import LayoutBanner from "./banner";
import LayoutFooter from "./footer";
import LayoutHeader from "./header";
import LayoutNavigation from "./navigation";
import { globalStyles } from "../../../../src/commons/styles/globalStyles";
import { Global } from "@emotion/react";
import LayoutBody from "../../../../pages/body";

const CHANGE_BODY = ["/14/", "/14/one/", "/14/two/", "/14/three/"];

const DEFAULT_BODY = ["/body/"];

export default function Layout(props) {
  const router = useRouter();


  return (
    <>
      <LayoutHeader />
      <LayoutNavigation />
      <div style={{ height: "300px", display: "flex" }}>
        <div style={{ width: "40%", backgroundColor: "skyblue" }}>sidebar</div>
        <div style={{ width: "70%" }}>{props.children}</div>
      </div>
      <LayoutFooter />
    </>
  );
}
