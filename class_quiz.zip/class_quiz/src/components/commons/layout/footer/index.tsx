import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 75px;
  background-color: green;
`;

export default function LayoutFooter() {
  return <Wrapper>footer</Wrapper>;
}
