import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 75px;
  background-color: red;
`;

export default function LayoutHeader() {
  return <Wrapper>footer</Wrapper>;
}
