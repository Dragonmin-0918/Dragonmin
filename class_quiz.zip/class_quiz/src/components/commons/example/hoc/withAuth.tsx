import { useEffect } from "react";
import { useRouter } from "next/router";

export const withAuth = (Component: any) => (props: any) => {
    const router = useRouter();

    useEffect(() => {
        if(localStorage.getItem("accessToken") === null) {
            alert("로그인 후 이용 가능")
           void router.push("/23/main");
        }
    }, []);

    return <Component {...props} />;
}