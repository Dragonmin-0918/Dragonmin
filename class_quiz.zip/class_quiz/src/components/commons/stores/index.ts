import { atom } from "recoil";
import { number } from "yup";

export const isEditState = atom({
    key: "isEditState",
    default: true,
});

export const accessTokenState = atom({
    key: "accessTokenState",
    default: "",
});

