import {useState} from "react";
import { string } from "yup";

interface IUseCountUp {
    count: number;
    onClickCountUp: () => void;

};

export const useCountUp = (): IUseCountUp => {

    const [count, setCount] = useState(0);
    const onClickCountUp = () => {
        setCount((prev) => prev + 1)
    }

    return {
        count,
        onClickCountUp,
    }
};