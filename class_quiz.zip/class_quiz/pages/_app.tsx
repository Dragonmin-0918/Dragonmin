// import "../styles/globals.css";
import Layout from "../src/components/commons/layout";
import ApolloSetting from "../src/components/commons/apollo";
import { Global } from "@emotion/react";
import { globalStyles } from "../src/commons/styles/globalStyles";
import { AppProps } from "next/app";
import { ApolloClient, ApolloProvider } from "@apollo/client";
import { InMemoryCache } from "@apollo/client";

export default function App({ Component}: AppProps){

  return (
    <div>
        <ApolloSetting>
          <>
          <Global styles={globalStyles}/>
        <Layout>
        <Component />
        </Layout>
        </>
        </ApolloSetting>
    </div>
  );
}
