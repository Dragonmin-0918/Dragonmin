import { Modal } from "antd";

export default function ModalAlertPage() {
  const onClickSuccess = () => {
    Modal.success({
      content: "게시글이 등록되었습니다.",
    });
  };
  return (
    <>
      <button onClick={onClickSuccess}>모달열기</button>
    </>
  );
}
