export default function RandomNumPage() {
  function randomNum() {
    let random = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
    document.getElementById("token").innerText = random;
  }

  return (
    <div>
      <div id="token">000000</div>
      <button onClick={randomNum}>인증번호전송</button>
    </div>
  );
}
