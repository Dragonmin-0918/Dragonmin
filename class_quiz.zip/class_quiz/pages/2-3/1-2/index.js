import { useState } from "react";

export default function RandomNumPage() {
  const [random, setRandom] = useState("000000");

  function randomNum() {
    setRandom(String(Math.floor(Math.random() * 1000000)).padStart(6, "0"));
  }

  return (
    <div>
      <div>{random}</div>
      <button onClick={randomNum}>인증번호전송</button>
    </div>
  );
}
