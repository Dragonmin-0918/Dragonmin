import { useMutation, gql } from "@apollo/client";
import { useRouter } from "next/router";
import type { ChangeEvent } from "react"
import {useState} from "react"
import { useRecoilState } from "recoil";
import { accessTokenState } from "../../../../src/commons/stores/index";
import type { IMutation, IMutationLoginUserArgs } from "../../../../src/commons/types/generated/types"; 

const LOGIN_USER = gql`
    mutation loginUser($email: String!, $password: String!){
        loginUser(email: $email, password: $password){
            accessToken
        }
    }
`

export default function LoginPage(): JSX.Element {
    const router = useRouter();
    

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loginUser] = useMutation<Pick<IMutation, "loginUser">, IMutationLoginUserArgs>(LOGIN_USER);

    const [, setAccessToken] = useRecoilState(accessTokenState)

    const onChangeEmail = (event: ChangeEvent<HTMLInputElement>): void => {
        setEmail(event.currentTarget.value);
    }   
    
    const onChangePassword = (event: ChangeEvent<HTMLInputElement>): void => {
        setPassword(event.currentTarget.value);
    }

    const onClickLogin = async (): Promise<void> => {
        const result = localStorage.getItem("accessToken");
        console.log(result);
        try{
       const result = await loginUser({
        variables: {email, password}
    });
    const accessToken = result.data?.loginUser.accessToken;

    if(accessToken === undefined) {
        alert("로그인에 실패했습니다. 다시 시도해 주세요.")
        return;
    }
    setAccessToken(accessToken);
    localStorage.setItem("accessToken", accessToken);
    void router.push("/23/hoc/main");
        } catch(error) {
           if (error instanceof Error) alert(error.message);
        } 
    };
    
    return (
        <>
            아이디: <input type="text" onChange={onChangeEmail}/>
            비밀번호: <input type="password"onChange={onChangePassword}/>
            <button onClick={onClickLogin}>로그인</button>
        </>
    )
}