import { useMutation, gql, useQuery } from "@apollo/client";

const FETCH_PRODUCTS = gql`
  query {
    fetchProducts {
      _id
      seller
      name
      detail
      price
    }
  }
`;

const DELETE_PRODUCT = gql`
  mutation deleteProduct($productId: ID) {
    deleteProduct(productId: $productId) {
      message
    }
  }
`;

export default function Moved() {
  const { data } = useQuery(FETCH_PRODUCTS);

  const [deleteProduct] = useMutation(DELETE_PRODUCT);

  const onClickDelete = (event) => {
    console.log(event.target.id);
    deleteProduct({
      variables: { productId: event.target.id },
      refetchQueries: [{ query: FETCH_PRODUCTS }],
    });
  };

  return (
    <div>
      {data?.fetchProducts.map((el) => (
        <div key={el._id}>
          <span>
            <input type="checkbox" />
            판매자: <span style={{ margin: "10px" }}>{el.seller}</span>
            상품명: <span style={{ margin: "10px" }}>{el.name}</span>
            상품설명: <span style={{ margin: "10px" }}>{el.detail}</span>
            가격: <span style={{ margin: "10px" }}>{el.price}</span>
          </span>
          <button id={el._id} onClick={onClickDelete}>
            삭제
          </button>
        </div>
      ))}
    </div>
  );
}
