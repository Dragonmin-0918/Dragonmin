import BoardWrite from "../../../src/components/units/board/07-write/BoardWrite.container";

export default function ProductsPage(props) {
  return (
    <div>
      <BoardWrite />
    </div>
  );
}
