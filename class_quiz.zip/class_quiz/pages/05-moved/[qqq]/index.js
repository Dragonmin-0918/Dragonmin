import { useRouter } from "next/router";
import { gql, useQuery } from "@apollo/client";

const FETCH_PRODUCT = gql`
  query fetchProduct($productId: ID) {
    fetchProduct(productId: $productId) {
      _id
      seller
      name
      detail
      price
    }
  }
`;

export default function Moved() {
  const router = useRouter();

  const { data } = useQuery(FETCH_PRODUCT, {
    variables: { productId: router.query.qqq },
  });

  return (
    <div>
      <div>판매자: {data && data.fetchProduct.seller}</div>
      <div>상품명: {data && data.fetchProduct.name}</div>
      <div>상품설명: {data && data.fetchProduct.detail}</div>
      <div>가격: {data && data.fetchProduct.price}</div>
    </div>
  );
}
