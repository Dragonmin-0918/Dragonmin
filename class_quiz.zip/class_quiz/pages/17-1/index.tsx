import { useState, useEffect } from "react";
import {useRouter} from "next/router";


export default function FunctionalCounterPage() {
    const [isChange, setIsChange] = useState(false)
    const router = useRouter();


    const onClickChange = (): void => {
   
        setIsChange(true)
    }
    const onClickMove = (): void => {
        void router.push("/")
    }
    useEffect(() => {
        alert("Rendered!!")
        
}, []);

    useEffect(() => {
            alert("Changed!!")
    }, [isChange]);


 

    useEffect(() => {
        return () => {
            alert("Bye!!")
        }
    }, []);



        return (
            <>
            <button onClick={onClickChange}>변경</button>
            <button onClick={onClickMove}>이동</button>
            </>
    )

}