export default function LayoutTwo() {
  return <div>body</div>;
}
