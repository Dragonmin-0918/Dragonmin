import { useForm } from 'react-hook-form'
import { wrapFormAsync } from '../../src/commons/libraries/asyncFunc';
import {yupResolver} from "@hookform/resolvers/yup"
import { schema } from './validation';
import Input01 from '../../src/commons/inputs/01/index';
import Button01 from '../../src/commons/buttons/01/index';


interface IFormData {
    writer: string;
    title: string;
    contents: string;
    email: string,
    password: string,
    phone: number
 
}
export default function GraphqlMutationPage(): JSX.Element {
    const {register, handleSubmit, formState} = useForm<IFormData>({
      resolver: yupResolver(schema),
      mode: "onChange",
    });

  const onClickSubmit = (data: IFormData): void => {
    console.log(data);
  };


  return  (
    <form onSubmit={wrapFormAsync(handleSubmit(onClickSubmit))}>
      작성자: <Input01 register={register("writer")} />
      <div style={{color: "red"}}>{formState.errors.writer?.message}</div>
      제목: <Input01 register={register("title")} />
      <div style={{color: "red"}}>{formState.errors.title?.message}</div>
      내용: <Input01 register={register("contents")} />
      <div style={{color: "red"}}>{formState.errors.contents?.message}</div>
      이메일: <Input01 register={register("email")} />
      <div style={{color: "red"}}>{formState.errors.email?.message}</div>
      비밀번호: <input type="password" {...register("password")} />
      <div style={{color: "red"}}>{formState.errors.password?.message}</div>
      휴대폰 번호: <input {...register("phone")} />
      <div style={{color: "red"}}>{formState.errors.phone?.message}</div>
      <Button01 title="등록하기" isActive={formState.isValid} />
    </form> 
  );
}