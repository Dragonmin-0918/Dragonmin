export default function LayoutBody() {
  return <div>바디영역</div>;
}
