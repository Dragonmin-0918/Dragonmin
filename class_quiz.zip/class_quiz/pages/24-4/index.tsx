import { useCountUp } from "../../src/components/hooks/useCountUp";



export default function QuizPage(): JSX.Element {
 

  const {count, onClickCountUp} = useCountUp()

  return (
    <>
      <div>
        <p>지금의 카운트는 {count} 입니다!</p>
        <button onClick={onClickCountUp}>Count up!</button>
      </div>
    </>
  );
}