export default function Numeric() {

const onClickButton = (id) => () => {
    console.log(id)
}

    return <button onClick={onClickButton(123)}>버튼</button>
}