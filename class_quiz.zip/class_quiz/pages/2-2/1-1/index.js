export default function Counter() {
  let result = 0;
  function increase() {
    result = result + 1;

    document.getElementById("result").innerText = result;
  }

  return (
    <div>
      <div id="result">0</div>
      <button id="upCount" onClick={increase}>
        카운트증가
      </button>
    </div>
  );
}
