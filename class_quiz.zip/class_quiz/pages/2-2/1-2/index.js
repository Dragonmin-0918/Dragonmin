import { useState } from "react";

export default function onClickCounter() {
  const [count, setCount] = useState(0);
  function oncClickUp() {
    setCount(count + 1);
  }

  return (
    <div>
      <div>{count}</div>
      <button onClick={oncClickUp}>카운트증가</button>
    </div>
  );
}
