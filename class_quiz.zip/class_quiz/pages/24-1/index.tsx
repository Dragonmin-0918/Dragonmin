import { useForm } from 'react-hook-form'
import { wrapAsync } from '../../src/commons/libraries/asyncFunc'

interface IFormData {
    writer: string;
    title: string;
    contents: string;
    password: string;
    errors: string;

}

export default function MyPage(): JSX.Element {
    const {register, handleSubmit, formState: {errors}} = useForm<IFormData>();

  const onClickSubmit = (data: IFormData): void => {
    console.log(data);
  };


  return  (
    <form onSubmit={handleSubmit(onClickSubmit)}>
      작성자: <input type="text" {...register("writer", {required: true})} />
      <div style={{color: "red"}}>{errors.writer && "작성자를 입력해주세요"}</div>
      제목: <input type="text" {...register("title", {required: true})} />
      <div style={{color: "red"}}>{errors.title && "제목을 입력해주세요"}</div>
      내용: <input type="text" {...register("contents", {required: true})} />
      <div style={{color: "red"}}>{errors.contents && "내용을 입력해주세요"}</div>
      비밀번호: <input type="password" {...register("password", {required: true})} />
      <div style={{color: "red"}}>{errors.password && "비밀번호를 입력해주세요"}</div>
      <button>등록하기</button>
    </form> 
  );
}
