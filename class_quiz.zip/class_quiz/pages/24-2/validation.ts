import * as yup from "yup"

export const schema = yup.object({
    writer: yup.string().min(5, "작성자명은 5자 이하로 입력 바랍니다.").required("작성자를 입력해주세요"),
    title: yup.string().max(100, "제목은 100자 이하로 입력 바랍니다.").required("제목을 입력해주세요"),
    contents: yup.string().max(1000, "내용은 1000자 이하로 입력 바랍니다.").required("내용을 입력해주세요"),
    email: yup.string().email("이메일 형식에 적합하지 않습니다.").required("이메일은 필수 입력 항목입니다."),
    password: yup.string().min(4, "비밀번호는 최소 4자리 이상 입력 바랍니다.").max(8, "비밀번호는 최대 8자리 이하로 입력 바랍니다.").matches(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{4,8}$/, "비밀번호는 특수문자를 포함해야 합니다.").required("비밀번호는 필수 입력 항목입니다."),
  });
  