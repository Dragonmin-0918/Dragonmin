import BoardWrite from "../../../../src/components/units/board/write/BoardWrite.container";

export default function GraphqlMutationPage(props) {
  return (
    <div>
      <BoardWrite />
    </div>
  );
}
