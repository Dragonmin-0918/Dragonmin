import DaumPostcodeEmbed from "react-daum-postcode";

export default function ModalAlertPage() {
  return (
    <>
      <DaumPostcodeEmbed />
    </>
  );
}
