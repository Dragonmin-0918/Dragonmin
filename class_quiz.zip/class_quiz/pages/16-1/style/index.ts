import styled from "@emotion/styled";

interface IonClickNumber {
  isActive: boolean;
}

export const PageStart = styled.span`
  color: ${(props: IonClickNumber) => (props.isActive ? "red" : "")};
  :hover {
    cursor: pointer;
  }
`;

export const Wrapper = styled.div`
  width: 1200px;
  /* margin: 100px; */
`;

export const Btn = styled.button`
  width: 171px;
  height: 52px;
  background-color: white;
  border-radius: 15px;
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
  cursor: pointer;
  color: black;

  :hover {
    background-color: #f5f2fc;
  }
`;
export const BtnImg = styled.img``;

export const ID = styled.div`
  width: 10%;
  text-align: center;
`;

export const Title = styled.div`
  width: 70%;
  text-align: center;
`;

export const Writer = styled.div`
  width: 10%;
  text-align: center;
`;

export const CreatedDate = styled.div`
  width: 10%;
  text-align: center;
`;

export const ELCreatedDate = styled.div`
  width: 10%;
  text-align: center;
`;

export const Mapping = styled.div`
  display: flex;
  flex-direction: row;
  height: 52px;
  line-height: 52px;
  border-bottom: 1px solid white;
`;

export const ELTitle = styled.div`
  width: 70%;
  text-align: center;
  cursor: pointer;

  :hover {
    color: blue;
  }
`;

export const ELWriter = styled.div`
  width: 10%;
  text-align: center;
`;

export const EL = styled.div`
  width: 10%;
  text-align: center;
`;

export const Container = styled.div`
  display: flex;
  flex-direction: row;
  height: 52px;
  line-height: 52px;
  border-bottom: 1px solid gray;
`;

export const BtnWrapper = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding-top: 50px;
`;

export const Top = styled.div`
  border-top: 2px solid white;
  margin-top: 20px;
`;

export const TopSub = styled.div`
  display: flex;
  flex-direction: row;
  height: 52px;
  line-height: 52px;
  border-bottom: 1px solid white;
  width: 1630px;

  :hover {
    color: blue;
  }
`;

export const InfiniteScroll = styled.div`
`
