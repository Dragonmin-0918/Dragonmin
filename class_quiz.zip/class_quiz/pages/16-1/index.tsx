import { FETCH_BOARDS } from "./queries/index";
import { useQuery } from "@apollo/client";
import BoarListUI from "./presenter/index";
import type {
  IQuery,
  IQueryFetchBoardsArgs,
} from "../../src/commons/types/generated/types";




export default function BoardDetail() {
  
  const { data, fetchMore } = useQuery<Pick<IQuery, "fetchBoards">, IQueryFetchBoardsArgs>(FETCH_BOARDS);

    const onLoadMore = (): void => {
      if(data === undefined) return;
      void fetchMore({
        variables: {page: Math.ceil((data?.fetchBoards.length ?? 10) / 10) + 1},
        updateQuery: (prev, {fetchMoreResult}) => {
          if(fetchMoreResult.fetchBoards === undefined){
            return {
              fetchBoards: [...prev.fetchBoards],
            };
          };
          return {
            fetchBoards: [...prev.fetchBoards, ...fetchMoreResult.fetchBoards],
          };
        },
      });
    };
 
  return (
    <BoarListUI
      data={data}
      onLoadMore={onLoadMore}
    />
  );
}
