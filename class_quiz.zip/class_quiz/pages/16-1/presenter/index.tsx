import {
  ID,
  Wrapper,
  Title,
  Writer,
  CreatedDate,
  Mapping,
  EL,
  Top,
  TopSub,
  ELWriter,
  ELTitle,
  ELCreatedDate,
} from "../style"

import { NewDate } from "../../utils/index";
import InfiniteScroll from 'react-infinite-scroller'

interface IBoardDetailUIProps {
  data: any;
  onLoadMore: any;


}

export default function BoardDetailUI(props: IBoardDetailUIProps) {
  return (
    <Wrapper>
      <Top />
      <TopSub>
        <ID>번호</ID>
        <Title>제목</Title>
        <Writer>작성자</Writer>
        <CreatedDate>날짜</CreatedDate>
      </TopSub>
      <div style={{height:"200px", width:"1630px", overflow:"auto"}}>
      <InfiniteScroll pageStart={0} loadMore={props.onLoadMore} hasMore={true} useWindow={false}>
      {props.data?.fetchBoards.map((el: any) => (

        <Mapping key={el._id}>
          <EL key={el._id} id={el._id}>
            {String(el._id).slice(-4).toUpperCase()}
          </EL>
          <ELTitle id={el._id}>
            {el.title}
          </ELTitle>
          <ELWriter key={el.writer} id={el.writer}>
            {el.writer}
          </ELWriter>
          <ELCreatedDate key={el.createdAt} id={el.createdAt}>
            {NewDate(el.createdAt)}
          </ELCreatedDate>
        </Mapping>
            ))}
           </InfiniteScroll>
          </div>
        
    </Wrapper>
  );
}
