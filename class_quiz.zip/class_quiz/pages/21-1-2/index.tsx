// container 부분
export default function Container() {
    return (
      <>
       {PresenterPage({child: "철수"}, {age: 13})}
      </>
    );
  }
  
// presenter 부분
  export default function PresenterPage(qqq: any) {
    return <div>{qqq.child}는 {qqq.age}살 입니다.</div>;
}
  
 