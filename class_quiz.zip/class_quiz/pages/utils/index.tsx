export const NewDate = (date: any) => {
  const DateData = new Date().toLocaleDateString();
  return DateData;
};
