import BoardWrite from "../../../src/components/units/board/write/BoardWrite.container";

export default function GraphqlMutationPage(props) {
  return <BoardWrite qqq="용민" />;
}
