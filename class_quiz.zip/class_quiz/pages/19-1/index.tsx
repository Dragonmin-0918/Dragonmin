import { useEffect, useRef } from "react";

export default function InputPasswordCursor() {

    const InputPassword = useRef<HTMLInputElement>(null);

    useEffect(() => {
        InputPassword.current?.focus();
    }, []);

    return (
    <input ref={InputPassword} type="password" />
    )
}