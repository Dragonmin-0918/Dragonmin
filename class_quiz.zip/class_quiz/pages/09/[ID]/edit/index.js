import ProductWrite from "../../../../src/components/units/product/09-write/ProductWrite.container";

export default function EditProductPage(props) {
  // 한 줄일때는 괄호() 필요 없음]
  return (
    <div>
      <ProductWrite isEdit={true} />
    </div>
  );
}
