import { useQuery, gql } from "@apollo/client";
import { useRouter } from "next/router";

const FETCH_PRODUCT = gql`
  query fetchProduct($productId: ID) {
    fetchProduct(productId: $productId) {
      seller
      name
      detail
      price
    }
  }
`;

export default function ProductPage(props) {
  const router = useRouter();
  console.log(router);

  const { data } = useQuery(FETCH_PRODUCT, {
    variables: { productId: router.query.ID },
  });

  console.log(data);

  const onClickMove = () => {
    router.push(`/09/${router.query.ID}/edit`);
    console.log(data);
  };

  return (
    <div>
      <div>판매자: {data?.fetchProduct?.seller}</div>
      <div>상품명: {data?.fetchProduct?.name}</div>
      <div>상품상세: {data?.fetchProduct?.detail}</div>
      <div>가격: {data?.fetchProduct?.price}</div>
      <button onClick={onClickMove}>수정</button>
    </div>
  );
}
