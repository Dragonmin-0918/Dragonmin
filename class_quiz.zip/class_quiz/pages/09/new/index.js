import ProductWrite from "../../../src/components/units/product/09-write/ProductWrite.container";

export default function NewProductPage() {
  return (
    <div>
      <ProductWrite isEdit={false} />
    </div>
  );
}
