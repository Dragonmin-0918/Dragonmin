import { useState } from "react";

export default function onClickChange() {
  const [button, setButton] = useState("안녕하세요");

  function onChangeButton() {
    setButton("반갑습니다");
  }

  return (
    <div>
      <button onClick={onChangeButton}>{button}</button>
    </div>
  );
}
