export default function CounterLetDocumentPage() {
  function onClickChange() {
    let ChangeBtn = document.getElementById("btn");
    ChangeBtn.innerText = "반갑습니다";
  }

  return (
    <div>
      <button id="btn" onClick={onClickChange}>
        안녕하세요
      </button>
    </div>
  );
}
