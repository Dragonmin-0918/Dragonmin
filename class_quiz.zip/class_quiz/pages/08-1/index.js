const classmates = [
  { name: "철수", age: 10, school: "토끼초등학교" },
  { name: "영희", age: 13, school: "다람쥐초등학교" },
  { name: "훈이", age: 11, school: "토끼초등학교" },
];

export default function schoolPage() {
  let values = [];

  const items = classmates.map((candy) => ({
    ...candy,
    candy: 10,
  }));

  values = [...items];

  const item = items.filter((item) => item.school === "토끼초등학교");

  return (
    <div>
      {item.map((el) => (
        <div>
          {el.name} {el.age} {el.school} {el.candy}
        </div>
      ))}
    </div>
  );
}
