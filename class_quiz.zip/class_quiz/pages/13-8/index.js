import { useState } from "react";

export default function Counter() {
  const [count, setCount] = useState(0);

  function onClickCounter() {
    setCount((prev) => prev + 1);
    setCount((prev) => prev + 2);
    setCount((prev) => prev + 3);
    setCount((prev) => prev + 4);
  }

  return (
    <div>
      <div>{count}</div>
      <button onClick={onClickCounter}>카운트</button>
    </div>
  );
}
