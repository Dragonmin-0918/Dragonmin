// presenter 부분
export default function Presenter(props: any) {
  return (
    <>
     {Presenter({child: "철수"}, {age: 13})}
    </>
  );
}