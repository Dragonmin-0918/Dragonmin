// container 부분
import PresenterPage from "./presenter";

export default function ContainerPage(): JSX.Element {


    return (
        <>
            {PresenterPage({child: "철수"})}
        </>
    )
}

// presenter 부분
export default function Container() {
    return (
      <>
       {PresenterPage({child: "철수"}, {age: 13})}
      </>
    );
  }
  
  