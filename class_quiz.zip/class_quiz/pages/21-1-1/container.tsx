// container 부분
import Presenter from "./presenter"
export default function Container(props: any): JSX.Element {


    return (
        <>
            {Container({child: "철수"})}
        </>
    )
}


  
  