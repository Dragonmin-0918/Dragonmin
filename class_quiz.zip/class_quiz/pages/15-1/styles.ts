import styled from "@emotion/styled";

interface IonClickNumber {
  isActive: boolean;
}

export const PageStart = styled.span`
  color: ${(props: IonClickNumber) => (props.isActive ? "red" : "")};
  :hover {
    cursor: pointer;
  }
`;
