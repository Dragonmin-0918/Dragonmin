import { useEffect, useState } from "react";
import {useRouter} from "next/router";

export default function FunctionalComponent() {
    const [count, setCount] = useState(0)
    const router = useRouter();

  useEffect(() => {
    console.log("컴포넌트가 마운트됐습니다~");
  }, []);


  useEffect(() => {
    return () => {
    alert("컴포넌트가 제거됩니다~");
    }
  }, []);

  const onClickButton = (): void => {
   setCount((prev) => prev + 1)
  };

	const onClickMove = (): void => {
		void router.push("/")
	}

  useEffect(() => {
    console.log("컴포넌트가 변경됐습니다~");

    return () => {
      console.log("마운트 시작")
  }
  },[onClickButton]);

    return (
      <>
        <div>카운트: {count}</div>
				<button onClick={onClickButton}>카운트(+1)</button>
        <button onClick={onClickMove}>이동하기</button>
      </>
    );
  }