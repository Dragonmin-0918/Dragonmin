import BordWrite from "../../../../src/components/units/22/write/container"
import {useRecoilState} from "recoil"
import { isEditState } from "../../../../src/commons/stores/index";
import { useEffect } from "react";

export default function RecoilNewPage (): JSX.Element {
    const [isEdit, setIsEdit] = useRecoilState(isEditState);

        useEffect(() => {
            setIsEdit(true);
        }, [])

    return <BordWrite />
}