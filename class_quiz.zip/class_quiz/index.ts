import { DataSource } from "typeorm";
import { Product } from "./Product.postgres";
import { Products } from "./Products.postgres";
import { ApolloServer } from '@apollo/server';
import { startStandaloneServer } from '@apollo/server/standalone';


const typeDefs = `#graphql
  input CreateProductInput {
    seller: String
    CreateProductInput!
  }


  type MyProduct {
    number: Int
    message: String
    _id: String
    name: String
    detail: String
    price: Int
    createdAt: Date
  }

  type MyProducts {
    number: Int
    message: String
    _id: String
    name: String
    detail: String
    price: Int
    createdAt: Date
  }

  type Query {
    fetchProduct(productId: ID): [MyProduct]
  }

  type Query {
    fetchProducts(page: Int): [MyProducts]
  }

  type Mutation {
    createProduct(createProductInput: CreateProductInput!): {
      _id: String
      number: Int
      message: String
    }
  }
`;

const resolvers = {
  Query: {
    fetchProduct: async () => {

      const result = await Product.find();
      console.log(result);


   
      return result;
    },
    fetchProducts: async () => {

      const result = await Products.find();
      console.log(result);
    }
  },

  Mutation: {
    createProduct: async (parent: any, args: any, context: any, info: any) => {
      await Product.insert({
        ...args.createProductInput,

      });

      return "상품 등록에 성공하였습니다.";
    },

    
    },
  };


// @ts-ignore
const server = new ApolloServer({
  typeDefs,
  resolvers,


});






const AppDataSource = new DataSource({
  type: "postgres",
  host: "34.64.244.122", 
  port: 5004, 
  username: "postgres",
  password: "postgres2022",
  database: "postgres",
  entities: [Product],
  synchronize: true,
  logging: true, 
});

AppDataSource.initialize()
 
  .then(() => {
    console.log("DB접속에 성공했습니다.");
    startStandaloneServer(server).then(() => {
      console.log("그래프큐엘 서버가 실행되었습니다.");
    });
  })
  .catch((error) => {
    console.log("DB접속에 실패했습니다.");
    console.log("원인: ", error);
  });
